package com.example.projecttwo;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    private DatabaseHelper databaseHelper;
    private int selectedItem = RecyclerView.NO_POSITION;

    private ItemButtonClickListener buttonClickListener;
    private ItemClickListener itemClickListener;

    private List<RowData> dataList;
    public interface ItemButtonClickListener {
        void onAddButtonClick(int position);
        void onSubtractButtonClick(int position);


    }
    public interface ItemClickListener {
        void onItemClick(int position);
    }
    public void setItemClickListener(ItemClickListener listener) {
        this.itemClickListener = listener;
    }
    public DataAdapter(List<RowData> dataList, DatabaseHelper dbHelper, ItemButtonClickListener listener) {
        this.dataList = dataList;
        this.databaseHelper = dbHelper;
        this.buttonClickListener = listener;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        RowData rowData = dataList.get(position);
        holder.tvLabel1.setText(rowData.getLabel1());
        holder.tvLabel2.setText(rowData.getLabel2());


        if (position == selectedItem) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.highlight_color));
        } else {
            holder.itemView.setBackgroundColor(Color.TRANSPARENT); // Reset background color
        }
        holder.itemView.setOnClickListener(v -> {
            if (itemClickListener != null) {
                itemClickListener.onItemClick(position);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            if (itemClickListener != null) {
                itemClickListener.onItemClick(position);
            }
        });
        holder.btnAdd.setOnClickListener(v -> {
            if (buttonClickListener != null) {
                buttonClickListener.onAddButtonClick(position);
            }
        });

        // Set click listener for delete button
        holder.btnSubtract.setOnClickListener(v -> {
            if (buttonClickListener != null) {
                buttonClickListener.onSubtractButtonClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvLabel1;
        TextView tvLabel2;
        ImageButton btnAdd;
        ImageButton btnSubtract;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvLabel1 = itemView.findViewById(R.id.tvLabel1);
            tvLabel2 = itemView.findViewById(R.id.tvLabel2);
            btnAdd = itemView.findViewById(R.id.btnAdd);
            btnSubtract = itemView.findViewById(R.id.btnSubtract);
        }
    }
    public void setSelectedItem(int position) {
        int previousItem = selectedItem;
        selectedItem = position;
        notifyItemChanged(previousItem);
        notifyItemChanged(selectedItem);
    }
    public void deleteItem(int position) {
        if (position >= 0 && position < dataList.size()) {
            dataList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, dataList.size());
        }
    }
    public String getItemIdAtPosition(int position) {
        if (position >= 0 && position < dataList.size()) {
            return dataList.get(position).getId(); // Assuming RowData has a method getId() that returns the item ID
        }
        return "Error";
    }

}

