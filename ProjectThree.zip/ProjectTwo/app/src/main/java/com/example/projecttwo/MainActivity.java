package com.example.projecttwo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MainActivity extends AppCompatActivity implements DataAdapter.ItemButtonClickListener,DataAdapter.ItemClickListener {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    private Button btnAddItem;
    private String userPhoneNumber;

    private Button btnRequestPermission;
    private Button btnDeleteRow;
    private RecyclerView recyclerView;
    private DataAdapter dataAdapter;
    private List<RowData> dataList;

    private DatabaseHelper databaseHelper;
    private int selectedItemPosition = RecyclerView.NO_POSITION;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_data);

        btnRequestPermission = findViewById(R.id.smsPermission);
        btnRequestPermission.setOnClickListener(v -> requestSmsPermissions());

        btnAddItem = findViewById(R.id.btnAddData);
        btnDeleteRow = findViewById(R.id.btnAddRow);

        recyclerView = findViewById(R.id.recyclerView);
        dataList = new ArrayList<>();

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Load items from the database and populate the RecyclerView
        Cursor cursor = databaseHelper.getAllItems();
        while (cursor.moveToNext()) {
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME));
            int itemAmount = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_AMOUNT));
            RowData rowData = new RowData(itemName, "Amount: " + itemAmount);
            dataList.add(rowData);
        }
        cursor.close();
        dataAdapter = new DataAdapter(dataList, databaseHelper, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(dataAdapter);
        dataAdapter.setItemClickListener(this);



        btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Launch the AddItemActivity when the button is clicked
                Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
                startActivity(intent);
            }
        });
        btnDeleteRow.setOnClickListener(v -> {
            if (selectedItemPosition != RecyclerView.NO_POSITION) {
                // Get the ID of the item to be deleted
                String itemId = dataAdapter.getItemIdAtPosition(selectedItemPosition);
                // Delete the item from the database
                databaseHelper.deleteItem(itemId);
                dataAdapter.deleteItem(selectedItemPosition);
                selectedItemPosition = RecyclerView.NO_POSITION; // Reset selection
            }
        });
    }

    private void requestSmsPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Request SMS permission and phone number
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Enable SMS Alerts");
            builder.setMessage("Enter your phone number to receive SMS alerts:");

            // Inflate a layout for the dialog
            View dialogView = getLayoutInflater().inflate(R.layout.dialog_enable_sms, null);
            builder.setView(dialogView);

            EditText etPhoneNumber = dialogView.findViewById(R.id.etPhoneNumber);

            builder.setPositiveButton("Enable", (dialog, which) -> {
                String phoneNumber = etPhoneNumber.getText().toString();
                // Save the phone number and request SMS permission
                if (!phoneNumber.isEmpty()) {
                    savePhoneNumber(phoneNumber);
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.SEND_SMS},
                            SMS_PERMISSION_REQUEST_CODE);
                } else {
                    showToast("Please enter a valid phone number.");
                }
            });

            builder.setNegativeButton("Cancel", null);

            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            // SMS permission already granted, ask if the user wants to disable SMS alerts
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Disable SMS Alerts");
            builder.setMessage("Do you want to disable SMS alerts?");
            builder.setPositiveButton("Yes", (dialog, which) -> {
                // Clear the saved phone number and disable SMS alerts
                clearPhoneNumber();
                showToast("SMS alerts disabled.");
            });
            builder.setNegativeButton("No", null);
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                showToast("SMS Permission granted.");
            } else {
                // Permission denied
                showToast("SMS Permission denied. Notifications will not be available.");
            }
        }
    }
    @Override
    public void onAddButtonClick(int position) {
        // Update database: Increment item amount by 1
        RowData rowData = dataList.get(position);
        int newAmount = parseAmount(rowData.getLabel2()) + 1;
        databaseHelper.updateItem(rowData.getId(), newAmount);

        // Update the data list and notify the adapter
        rowData.setLabel2("Amount: " + newAmount);
        dataAdapter.notifyItemChanged(position);
    }

    @Override
    public void onSubtractButtonClick(int position) {
        // Update database: Decrement item amount by 1
        RowData rowData = dataList.get(position);
        int newAmount = parseAmount(rowData.getLabel2()) - 1;

        if (newAmount >= 0) {
            databaseHelper.updateItem(rowData.getId(), newAmount);

            // Update the data list and notify the adapter
            rowData.setLabel2("Amount: " + newAmount);
            dataAdapter.notifyItemChanged(position);
        }
        if(newAmount < 5){
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                SmsManager smsManager = SmsManager.getDefault();
                String alertMessage = "Alert: Low Inventory!";
                String phoneNumber = "5551234567"; // Replace with the user's phone number

                smsManager.sendTextMessage(phoneNumber, null, alertMessage, null, null);
            } else {
                // Handle the case where SMS permission is not granted
                // For example, show a toast message indicating SMS alerts are disabled
                showToast("SMS alerts are disabled.");
            }
        }
    }
    @Override
    public void onItemClick(int position) {
        selectedItemPosition = position;
        dataAdapter.setSelectedItem(position);
    }

    private int parseAmount(String label) {
        // Extract the item amount from the label
        String[] parts = label.split(": ");
        return Integer.parseInt(parts[1]);
    }
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    private void savePhoneNumber(String number){
        userPhoneNumber = number;
    }
    private void clearPhoneNumber(){
        userPhoneNumber = null;
    }
}
