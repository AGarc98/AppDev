package com.example.projecttwo;

public class RowData {
    private String label1;
    private String label2;

    public RowData(String label1, String label2) {
        this.label1 = label1;
        this.label2 = label2;
    }

    public String getLabel1() {
        return label1;
    }

    public String getId(){
        return label1;}

    public void setLabel1(String label1) {
        this.label1 = label1;
    }

    public String getLabel2() {
        return label2;
    }

    public void setLabel2(String label2) {
        this.label2 = label2;
    }
}
