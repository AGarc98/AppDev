package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private EditText etItemName, etCurrentInventory;
    private Button btnAdd;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);

        etItemName = findViewById(R.id.etItemName);
        etCurrentInventory = findViewById(R.id.etCurrentInventory);
        btnAdd = findViewById(R.id.btnAdd);

        databaseHelper = new DatabaseHelper(this);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etItemName.getText().toString().trim();
                int currentInventory = Integer.parseInt(etCurrentInventory.getText().toString());

                long newRowId = databaseHelper.insertItem(name, currentInventory);
                if (newRowId != -1) {
                    showToast("Item added successfully");
                    startMainActivity();

                } else {
                    showToast("Failed to add item");
                }
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    private void startMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish(); // Close LoginActivity so the user can't go back to it without logging out
    }
}
